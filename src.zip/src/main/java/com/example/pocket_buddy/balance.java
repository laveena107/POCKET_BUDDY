package com.example.pocket_buddy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class balance extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_balance);
    }
}