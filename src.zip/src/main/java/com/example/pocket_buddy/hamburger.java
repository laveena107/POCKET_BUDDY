package com.example.pocket_buddy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class hamburger extends AppCompatActivity {


    ImageView i1,i2,i3,i4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hamburger);

        i1=findViewById(R.id.imageView34);
        i2=findViewById(R.id.imageView33);
        i3=findViewById(R.id.imageView35);
        i4=findViewById(R.id.imageView36);

        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in2 = new Intent(getApplicationContext(),home.class);
                startActivity(in2);

            }
        });

     i1.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             Intent in1 = new Intent(getApplicationContext(),dashboard.class);
             startActivity(in1);
         }
     });

        i3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in3 = new Intent(getApplicationContext(),balance.class);
                startActivity(in3);
            }
        });


    }
}