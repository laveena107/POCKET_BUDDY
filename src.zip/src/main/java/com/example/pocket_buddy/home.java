package com.example.pocket_buddy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class home extends AppCompatActivity {


    ImageView i,i1,i2;

    TextView t;
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        i2=findViewById(R.id.imageView44);
        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in5= new Intent(getApplicationContext(),Msg.class);
                startActivity(in5);
            }
        });

        t=findViewById(R.id.textView22);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in3 = new Intent(getApplicationContext(),points.class);
                startActivity(in3);
            }
        });

        i1=findViewById(R.id.imageView31);
        i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in1 = new Intent(getApplicationContext(),search.class);
                startActivity(in1);
            }
        });
        i=findViewById(R.id.imageView30);
        i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getApplicationContext(),hamburger.class);
                startActivity(in);
            }
        });
        bottomNavigationView= findViewById(R.id.bottom_navigator);

        bottomNavigationView.setSelectedItemId(R.id.home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId())
                {
                    case R.id.home:
                        return true;

                    case R.id.pocket:
                        startActivity(new Intent(getApplicationContext(), food.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.Leaderboard:
                        startActivity(new Intent(getApplicationContext(),community.class));
                        overridePendingTransition(0,0);
                        return true;
                }


                return false;
            }
        });

    }
}